/*
 * ==============================================================================
 * PlantoPRO / Smart Gardening System Arduino Firmware
 * ==============================================================================
 * Target Microcontroller: Arduino Uno / Nano / Pro Mini (ATmega328P)
 * Baud Rate: 9600 Baud (8-N-1)
 * 
 * Hardware Channel Mapping:
 * ------------------------------------------------------------------------------
 *   - Soil Sensor 1 : Analog Pin A0 (Calibrated 300=Wet 100%, 800=Dry 0%)
 *   - Soil Sensor 2 : Analog Pin A1 (Calibrated 300=Wet 100%, 800=Dry 0%)
 *   - DHT11 Sensor  : Digital Pin 4 (Canopy Temperature °C & Humidity %RH)
 *   - Pump 1 Relay  : Digital Pin 7 (Field 1: Auto on Soil 1 < 40% | Manual: '1')
 *   - Pump 2 Relay  : Digital Pin 6 (Field 2: Auto on Soil 2 < 40% | Manual: '2')
 *   - Pump 3 Relay  : Digital Pin 8 (Manual Override Valve ONLY: Triggered by '3')
 * 
 * Operating Logic:
 * ------------------------------------------------------------------------------
 *   - PUMP 1 (D7) : Works BOTH automatically (Soil 1 < 40%) & manually (cmd '1')
 *   - PUMP 2 (D6) : Works BOTH automatically (Soil 2 < 40%) & manually (cmd '2')
 *   - PUMP 3 (D8) : STRICTLY MANUAL ONLY! Never triggers on sensor conditions.
 *                   Only fires when commanded via Serial '3'.
 * 
 * Serial Inbound Commands (9600 Baud):
 *   '1' -> Manually trigger Pump 1 pulse (3 seconds)
 *   '2' -> Manually trigger Pump 2 pulse (3 seconds)
 *   '3' -> Manually trigger Pump 3 pulse (3 seconds - Manual Valve)
 *   'A' -> Enable Auto Mode for Pumps 1 & 2 (Manual override still works)
 *   'M' -> Pause Auto Mode (Pumps 1, 2, 3 become manual-only)
 *   'X' or '0' -> Emergency Stop (Immediately shuts off all pumps)
 *   'S' -> Immediate Telemetry Query
 * ==============================================================================
 */

#include <DHT.h>

// ---------- Pin Definitions ----------
#define SOIL1_PIN    A0     // Field 1 Soil Moisture Sensor
#define SOIL2_PIN    A1     // Field 2 Soil Moisture Sensor
#define DHT_PIN      4      // DHT11 Ambient Temperature & Humidity Sensor
#define DHTTYPE      DHT11

const uint8_t NUM_PUMPS = 3;
// Index 0 = Pump 1 (D7), Index 1 = Pump 2 (D6), Index 2 = Pump 3 (D8 - Manual Only)
const uint8_t RELAY_PINS[NUM_PUMPS] = {7, 6, 8};

DHT dht(DHT_PIN, DHTTYPE);

// ---------- Calibration Parameters ----------
const int DRY_VALUE          = 800; // Raw ADC reading in dry soil (0%)
const int WET_VALUE          = 300; // Raw ADC reading in saturated soil (100%)
const int MOISTURE_THRESHOLD = 40;  // Auto-irrigation threshold percentage (40%)

// ---------- Mode Control ----------
bool autoModeEnabled = true; // true = Auto (Pumps 1&2) + Manual | false = Manual Only

// ---------- Active-LOW Relay Logic ----------
// Standard relay modules energize on LOW and de-energize on HIGH
const bool RELAY_ACTIVE_LOW  = true;
const uint8_t RELAY_ON       = RELAY_ACTIVE_LOW ? LOW  : HIGH;
const uint8_t RELAY_OFF      = RELAY_ACTIVE_LOW ? HIGH : LOW;

// ---------- Non-Blocking Timing Rules (milliseconds) ----------
const unsigned long CHECK_INTERVAL = 5000; // 5s telemetry & sensor check cycle
const unsigned long PUMP_RUN_TIME  = 3000; // 3s active pump pulse duration
const unsigned long PUMP_COOLDOWN  = 3000; // 3s safety cooldown between pulses

// ---------- Pump State Variables ----------
bool          pumpRunning[NUM_PUMPS]   = {false, false, false};
unsigned long pumpStartTime[NUM_PUMPS] = {0, 0, 0};
unsigned long pumpLastEnd[NUM_PUMPS]   = {0, 0, 0};

unsigned long lastCheck = 0;

// ==============================================================================
// HARDWARE INITIALIZATION
// ==============================================================================
void setup() {
  Serial.begin(9600);

  // Anti-Glitch Protection: Write RELAY_OFF before setting pinMode to OUTPUT
  // This prevents active-LOW relays from momentary power-on click/glitch on boot
  for (uint8_t i = 0; i < NUM_PUMPS; i++) {
    digitalWrite(RELAY_PINS[i], RELAY_OFF);
    pinMode(RELAY_PINS[i], OUTPUT);
  }

  dht.begin();

  Serial.println(F("Smart gardening system starting..."));
  Serial.println(F("Pumps: Pump 1(D7 auto/man), Pump 2(D6 auto/man), Pump 3(D8 MANUAL ONLY)"));
  Serial.println(F("Commands: '1'=Pump1 | '2'=Pump2 | '3'=Pump3(Manual) | 'A'=Auto ON | 'M'=Manual Only | '0'/'X'=Stop All"));
}

// ==============================================================================
// SENSOR READING & ADC SETTLING FILTERS
// ==============================================================================

// Fast analog read with settling pause to eliminate ADC multiplexer crosstalk
int readAnalogFiltered(uint8_t pin) {
  analogRead(pin);       // Dummy read to charge the internal ADC sample capacitor
  delayMicroseconds(20); // Settling pause
  int r1 = analogRead(pin);
  int r2 = analogRead(pin);
  return (r1 + r2) / 2;  // 2-sample average
}

// Converts raw analog reading into calibrated 0% - 100% moisture percentage
int readMoisturePercent(uint8_t pin) {
  int raw = readAnalogFiltered(pin);
  return constrain(map(raw, DRY_VALUE, WET_VALUE, 0, 100), 0, 100);
}

// ==============================================================================
// PUMP ACTUATION & TIMING CONTROLS
// ==============================================================================

// Starts a pump safely if not already running and not in cooldown
bool startPump(uint8_t i) {
  if (i >= NUM_PUMPS) return false;
  unsigned long now = millis();

  if (pumpRunning[i]) return false; // Already dispensing

  if (pumpLastEnd[i] != 0 && (now - pumpLastEnd[i] < PUMP_COOLDOWN)) {
    Serial.print(F("Pump "));
    Serial.print(i + 1);
    Serial.println(F(" skipped (cooldown)"));
    return false;
  }

  pumpRunning[i]   = true;
  pumpStartTime[i] = now;
  digitalWrite(RELAY_PINS[i], RELAY_ON);

  Serial.print(F("Pump "));
  Serial.print(i + 1);
  Serial.println(F(" ON"));
  return true;
}

// Automatically shuts off pump after PUMP_RUN_TIME (3 seconds)
void updatePump(uint8_t i) {
  if (pumpRunning[i] && (millis() - pumpStartTime[i] >= PUMP_RUN_TIME)) {
    digitalWrite(RELAY_PINS[i], RELAY_OFF);
    pumpRunning[i] = false;
    pumpLastEnd[i] = millis();

    Serial.print(F("Pump "));
    Serial.print(i + 1);
    Serial.println(F(" OFF"));
  }
}

// Emergency stop - shuts down all pumps immediately
void stopAllPumps() {
  unsigned long now = millis();
  for (uint8_t i = 0; i < NUM_PUMPS; i++) {
    digitalWrite(RELAY_PINS[i], RELAY_OFF);
    pumpRunning[i] = false;
    pumpLastEnd[i] = now;
  }
  Serial.println(F("All pumps shut OFF immediately."));
}

// Shuts down a specific pump immediately
void stopPump(uint8_t i) {
  if (i >= NUM_PUMPS) return;
  digitalWrite(RELAY_PINS[i], RELAY_OFF);
  pumpRunning[i] = false;
  pumpLastEnd[i] = millis();
  Serial.print(F("Pump "));
  Serial.print(i + 1);
  Serial.println(F(" OFF (Manual Stop)"));
}

// ==============================================================================
// TELEMETRY TRANSMISSION & AUTOMATIC THRESHOLD EVALUATION
// ==============================================================================
void checkSensorsAndAutomate() {
  int soil1 = readMoisturePercent(SOIL1_PIN);
  int soil2 = readMoisturePercent(SOIL2_PIN);
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();
  bool dhtOk = !isnan(temp) && !isnan(hum);

  // Standard PlantoPRO telemetry stream format
  Serial.print(F("SOIL1="));
  Serial.print(soil1);
  Serial.print(F("%  SOIL2="));
  Serial.print(soil2);
  Serial.print(F("%  TEMP="));
  if (dhtOk) Serial.print(temp, 1); else Serial.print(F("ERR"));
  Serial.print(F("C  HUMIDITY="));
  if (dhtOk) Serial.print(hum, 1); else Serial.print(F("ERR"));
  Serial.print(F("%  MODE="));
  Serial.println(autoModeEnabled ? F("AUTO") : F("MANUAL"));

  // Automatic Trigger Logic (only active if autoModeEnabled == true)
  if (autoModeEnabled) {
    // 1. Pump 1: Field 1 auto-irrigation when soil moisture is low
    if (soil1 < MOISTURE_THRESHOLD) {
      startPump(0);
    }

    // 2. Pump 2: Field 2 auto-irrigation when soil moisture is low
    if (soil2 < MOISTURE_THRESHOLD) {
      startPump(1);
    }

    // PUMP 3 IS STRICTLY MANUAL ONLY:
    // It is NEVER triggered here automatically. It only activates via serial command '3'.
  }
}

// ==============================================================================
// INBOUND SERIAL COMMAND PARSER (MANUAL CONTROL & MODE SWITCHING)
// ==============================================================================
void processSerialCommands() {
  while (Serial.available() > 0) {
    char cmd = Serial.read();

    // Discard whitespace / line feeds
    if (cmd == '\r' || cmd == '\n' || cmd == ' ') continue;

    switch (cmd) {
      // --- Manual Pump Triggers (All 3 pumps can be triggered manually) ---
      case '1':
        Serial.println(F("[MANUAL] Triggering Pump 1"));
        startPump(0);
        break;

      case '2':
        Serial.println(F("[MANUAL] Triggering Pump 2"));
        startPump(1);
        break;

      case '3':
        // Pump 3: Manual Override Valve
        Serial.println(F("[MANUAL] Triggering Pump 3 (Manual Valve)"));
        startPump(2);
        break;

      // --- Mode Selection for Pumps 1 & 2 ---
      case 'A':
      case 'a':
        autoModeEnabled = true;
        Serial.println(F("[MODE] Automatic Mode ENABLED (Pumps 1 & 2 auto + manual)"));
        break;

      case 'M':
      case 'm':
        autoModeEnabled = false;
        Serial.println(F("[MODE] Manual-Only Mode ENABLED (Auto triggers paused)"));
        break;

      // --- Emergency / Manual Stop ---
      case 'X':
      case 'x':
      case '0':
        Serial.println(F("[COMMAND] Emergency Stop triggered"));
        stopAllPumps();
        break;

      // --- Telemetry Status Query ---
      case 'S':
      case 's':
      case '?':
        checkSensorsAndAutomate();
        break;

      default:
        // Ignore unrecognized bytes
        break;
    }
  }
}

// ==============================================================================
// MAIN LOOP
// ==============================================================================
void loop() {
  // 1. Instantly process any manual commands ('1', '2', '3', 'A', 'M', 'X')
  processSerialCommands();

  // 2. Service non-blocking 3-second pump duration timers
  for (uint8_t i = 0; i < NUM_PUMPS; i++) {
    updatePump(i);
  }

  // 3. Periodic telemetry transmission and automatic threshold checks (every 5 seconds)
  if (millis() - lastCheck >= CHECK_INTERVAL) {
    lastCheck = millis();
    checkSensorsAndAutomate();
  }
}
